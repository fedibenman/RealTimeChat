import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-unfound',
  templateUrl: './unfound.component.html',
  styleUrls: ['./unfound.component.css']
})
export class UnfoundComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
