
   export interface Message {
    type: string;
    conversationId: string;
    data: any;
  }